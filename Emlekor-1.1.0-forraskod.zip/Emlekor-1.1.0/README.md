# Emlékőr 1.1.0

Magyar, offline emléknapló Androidra. **Értéket teremtünk. Emlékeket védünk.**
Napi pár perces, vezetett írás gyerekekkel közös használathoz, felnőtteknek és idősebbeknek.
Android 8.0+ (minSdk 26), csomagnév `hu.emlekor.naplo`. A régi Emlékőrre frissítésként telepíthető
az eredeti aláírókulccsal; az alkalmazást ne távolítsd el előtte.

## Az új verzió

- Saját rajzolt emlékkönyv, részletesen növekvő kert, képes naplókártyák és hangulatok.
- Nyolc választható emlékösvény, ösvényenként három valódi emlékkel.
- Hat automatikus emlékalbum és tizenkét képes jelvény.
- Négy kert: tisztás, alkony, csillagliget és ősz; 0/30/70/150 emléklevélnél választhatók.
- Egy külön írással töltött nap 10 levelet ad. Nincs elkölthető egyenleg, elvesző sorozat vagy időkorlát.
- A hangulatválasztás nem módosítja a jutalmat: a nehéz emlék is ugyanúgy számít.

A háromlépéses naplóírás, piszkozatmentés, segítő kérdések, kulcsszavak, keresés, kedvencek,
visszaolvasás, szerkesztés és nagyobb betűméret megmarad. A szövegrendezés csak a megadott
részleteket használja, eseményt vagy érzést nem talál ki.

## Mentés

Androidon a napló az alkalmazás privát tárában, Keystore-kulccsal titkosítva tárolódik.
**Beállítások → Jelszavas biztonsági másolat** készít hordozható `.emlekor` fájlt.
Másik telefonon: **Mentés visszatöltése**, fájl és jelszó megadása, majd megerősítés.

A meglévő emlékek megmaradnak; az eltérő változatok külön bejegyzésként őrződnek meg,
az azonosak nem duplázódnak. Az import nem ad újabb pontot ugyanazokért az emlékekért.
A jelszó nem állítható helyre. A helyi titkosítás mellett is készíts külön másolatot:
eltávolításkor vagy a telefon elvesztésekor a helyi adattár is elveszhet.
A régi, 1.0-s mentések beolvashatók. A piszkozat és a napló mentési formátuma nem változott.

## A saját tempódban

Az ösvény a kezdéskor egy eltávolítható kulcsszót tesz az emlékhez. E jelölés alapján számolja
az ösvény haladását, nem elemzi és nem pontozza a személyes történet tartalmát.
Az albumok kulcsszavas nézetek, ugyanaz az emlék több albumban is megjelenhet. A haladás
az aktuálisan meglévő emlékekből számolódik, ezért törlés után újraszámolódik.

## Fejlesztés és átadás

- [PROJECT_HANDOFF.md](PROJECT_HANDOFF.md): projektcél, döntések és a Codex általi átvétel.
- [AGENTS.md](AGENTS.md): adatvédelmi, kompatibilitási és fejlesztési szabályok.
- [BUILDING.md](BUILDING.md): APK-build és megismételhető tesztek.
- [VALIDATION.md](VALIDATION.md): eredmények és vizsgálati korlátok.
- [CHANGELOG.md](CHANGELOG.md): változásnapló.

A GitHubra előkészített forráscsomag **nem tartalmaz aláírókulcsot vagy személyes naplót**.
A kulcs külön privát ZIP-ben van; sem azt, sem a jelszavát ne töltsd a repositoryba.

Az alkalmazás helyi HTML/CSS/JavaScript + Java WebView. Nincs internetes szolgáltatás,
fiók, reklám, analitika, külső betűtípus, fotó-, hang- vagy felhőszinkron.
Minden grafika saját, szerkeszthető SVG a `memory-art.js` modulban; nincs stockkép vagy
külső grafikai függőség. Az eredeti launcherikonok is saját rajzok.
A saját kód nyílt forrású licencéről a tulajdonos még nem döntött.
